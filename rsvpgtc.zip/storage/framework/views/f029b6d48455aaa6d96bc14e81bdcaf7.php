<!doctype html>
<html lang="en" class="h-100 w-100">

<head>
    <title>RSVP GTC Easter</title>

    

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- Required CSS files -->
    <link href="css/style.min.css" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" href="img/GTClogo.png" sizes="32x32" type="image/png">
    <link rel="icon" href="img/GTClogo.png" sizes="16x16" type="image/png">
    <link rel="icon" href="img/gtcico.ico">
</head>

<body id="page-top" class="h-100 overflow-x-hidden w-100">

    <!-- Preloader Start -->
    
    <!-- Preloader End -->


    <!-- Header Start -->
    <header class="fixed-top">
        <nav class="navbar navbar-expand-lg p-0">
            <div class="container">
                <!-- Navbar brand (mobile) -->
                <div class="navbar-brand align-items-center d-flex d-lg-none me-0">
                    <img width="100" height="100" src="img/GTClogo.png" alt="Logo">
                </div>

                <!-- Navbar toggler -->
                

                <!-- Navbar menu -->
                

                    <!-- Navbar brand (desktop) -->
                    <div class="navbar-brand d-none d-lg-block mx-3 mx-xl-4 position-relative text-center">
                        <img width="180" height="180" src="img/GTClogo.png" alt="Logo" class="mt-4 position-absolute start-0 top-0">
                    </div>

                    
                    </ul>
                </div>
                <!-- //.collapse -->
            </div>
            <!-- //.container -->
        </nav>
    </header>
    <!-- Header End -->


    <!-- Spacer -->
    <span class="spacer d-block w-100"></span>


   


    <!-- Section - The Couple Start -->
    <section id="the-couple">
        <div class="container position-relative z-2">
            <div class="row mb-5 pb-lg-5">
                <div class="col-12 position-relative text-center z-2">
                    <iframe src="https://docs.google.com/forms/d/e/1FAIpQLSfkZpnkzBHTetZTsiIr_ifnSEz1GB-gnVmLsrpO3Iiem9zAqA/viewform?embedded=true" width="400" height="1227" frameborder="0" marginheight="0" marginwidth="0">Memuat…</iframe>
                    
                </div>
                <!-- //.col-12 -->
            </div>
            <!-- //.row -->

            
            <!-- //.row -->
        </div>
        <!-- //.container -->

        <!-- SVG Image -->
        <img src="img/shape-wave-top-left-1.svg" alt="" class="shape-wave shape-wave-sm d-none d-lg-block mt-5 position-absolute start-0 top-0 z-1">
        <img src="img/shape-wave-bottom-right-2.svg" alt="" class="shape-wave bottom-0 d-none d-lg-block end-0 position-absolute z-1">
    </section>
    <!-- Section - The Couple End -->


    


    


    


   


    


   


   


    <!-- Footer Start -->
   


    <!-- Required JS files -->
    <script src="js/script.min.js"></script>
</body>

</html><?php /**PATH D:\laragon\www\rsvpgtc\resources\views/welcome.blade.php ENDPATH**/ ?>